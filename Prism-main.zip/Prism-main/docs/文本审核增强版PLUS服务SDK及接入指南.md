本文介绍文本审核增强版PLUS服务SDK接入的方式。

## 步骤一：开通服务

访问[开通服务](https://common-buy.aliyun.com/?commodityCode=lvwang_cip_public_cn)页面，开通文本审核增强版服务。

开通文本增强版服务后，默认付费方式是按量后付费，且按照实际用量结算当日费用，不调用服务不收费。接口接入使用后系统会按使用量自动出账。您也可以[购买按量抵扣资源包](https://common-buy.aliyun.com/?commodityCode=lvwang_cipbag_dp_cn)，资源包相较于后付费存在一定阶梯折扣，适合使用量级可预期和较大的用户。

## 步骤二：为RAM用户授权

在接入SDK或者API之前，您需要为RAM用户授权。您可以为阿里云账号和RAM用户创建一个访问密钥（AccessKey）。在调用阿里云API时您需要使用AccessKey完成身份验证。获取方式，请参见[获取AccessKey](https://help.aliyun.com/zh/ram/obtain-an-accesskey-pair-3#task-354412)。

### 操作步骤

1.  使用阿里云账号登录[RAM控制台](https://ram.console.aliyun.com/)。
    
2.  创建RAM用户。
    
    具体操作，请参见[创建RAM用户](https://help.aliyun.com/zh/ram/user-guide/create-a-ram-user#task-187540)。
    
3.  向RAM用户授权系统策略权限：`AliyunYundunGreenWebFullAccess`。
    
    具体操作，请参见[管理RAM用户的权限](https://help.aliyun.com/zh/ram/user-guide/grant-permissions-to-the-ram-user#task-187800)。
    
    完成以上配置后，您可以使用RAM用户调用内容安全API。
    

## 步骤三：安装并接入SDK

目前支持的接入地域如下：

| **地域** | **外网接入地址** | **内网接入地址** | 支持服务 |
| --- | --- | --- | --- |
| 华东2（上海） | green-cip.cn-shanghai.aliyuncs.com | green-cip-vpc.cn-shanghai.aliyuncs.com | ugc\\_moderation\\_byllm、ugc\\_moderation\\_byllm\\_pro、nickname\\_detection\\_pro、chat\\_detection\\_pro、comment\\_detection\\_pro、ad\\_compliance\\_detection\\_pro、text\\_aigc\\_detectorugc\\_moderation\\_byllm\\_ec |
| 华北2（北京） | green-cip.cn-beijing.aliyuncs.com | green-cip-vpc.cn-beijing.aliyuncs.com |
| 华东1（杭州） | green-cip.cn-hangzhou.aliyuncs.com | green-cip-vpc.cn-hangzhou.aliyuncs.com |
| 华南1（深圳） | green-cip.cn-shenzhen.aliyuncs.com | green-cip-vpc.cn-shenzhen.aliyuncs.com |
| 西南1（成都） | green-cip.cn-chengdu.aliyuncs.com | 暂无  |
| 中国香港 | green-cip.cn-hongkong.aliyuncs.com | green-cip-vpc.cn-hongkong.aliyuncs.com | ugc\\_moderation\\_byllm\\_cb |
| 新加坡 | green-cip.ap-southeast-1.aliyuncs.com | green-cip-vpc.ap-southeast-1.aliyuncs.com | ugc\\_moderation\\_byllm\\_cb、comment\\_multilingual\\_pro\\_cb |
| 英国（伦敦） | green-cip.eu-west-1.aliyuncs.com | 暂无  |
| 美国（弗吉尼亚） | green-cip.us-east-1.aliyuncs.com | green-cip-vpc.us-east-1.aliyuncs.com |
| 美国（硅谷） | green-cip.us-west-1.aliyuncs.com | 暂无  |
| 德国（法兰克福） | green-cip.eu-central-1.aliyuncs.com | green-cip-vpc.eu-central-1.aliyuncs.com |

**说明**

如果需要其他语言的SDK示例代码，您可以通过[OpenAPI开发者门户](https://api.aliyun.com/api/Green/2022-03-02/TextModerationPlus)在线调试工具调试API接口，该工具会自动生成相应API的SDK调用示例代码。

阿里云SDK代码通过定义`ALIBABA_CLOUD_ACCESS_KEY_ID`和`ALIBABA_CLOUD_ACCESS_KEY_SECRET`环境变量来创建默认的访问凭证。调用接口时，程序直接访问凭证，读取您的访问密钥（即AccessKey）并自动完成鉴权。您在接入SDK代码示例之前，请先配置环境变量。具体操作，请参见[身份验证配置](https://help.aliyun.com/zh/sdk/developer-reference/credentials-1)。

SDK分为两个版本服务，推荐直接接入本页面的PLUS服务，如果您之前是接入的通用服务，请参考[文本审核增强版通用服务SDK及接入指南](https://help.aliyun.com/zh/document_detail/2933065.html)。

### **文本审核增强版PLUS服务**

该SDK对应接口为[文本审核增强版PLUS服务](https://help.aliyun.com/zh/document_detail/2684669.html)、[基于大模型能力构建的文本审核服务](https://help.aliyun.com/zh/document_detail/2866911.html)、[面向大语言模型的文本审核PLUS服务](https://help.aliyun.com/zh/document_detail/2671445.html)、[文本审核增强版多语言PLUS服务](https://help.aliyun.com/zh/document_detail/2938197.html)。

### Java SDK

支持Java 1.8及以上版本。

原始代码，请参见[Java SDK源码](https://github.com/aliyun/alibabacloud-java-sdk/tree/master/green-20220302)或者[Java SDK源码（OSS路径）](https://s01.oss.sonatype.org/#nexus-search;quick~green20220302)。

在pom.xml中加入相应依赖，就可以在Maven工程中使用SDK。

1、在dependencies中添加如下依赖。

```
<dependency>
  <groupId>com.aliyun</groupId>
  <artifactId>green20220302</artifactId>
  <version>3.3.3</version>
</dependency>
```

2、接入Java SDK 代码示例。

```
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.aliyun.green20220302.Client;
import com.aliyun.green20220302.models.TextModerationPlusRequest;
import com.aliyun.green20220302.models.TextModerationPlusResponse;
import com.aliyun.green20220302.models.TextModerationPlusResponseBody;
import com.aliyun.teaopenapi.models.Config;


public class TextModerationPlusDemo {

    public static void main(String[] args) throws Exception {
        Config config = new Config();
        /**
         * 阿里云账号AccessKey拥有所有API的访问权限，建议您使用RAM用户进行API访问或日常运维。
         * 常见获取环境变量方式：
         * 方式一：
         *     获取RAM用户AccessKey ID：System.getenv("ALIBABA_CLOUD_ACCESS_KEY_ID");
         *     获取RAM用户AccessKey Secret：System.getenv("ALIBABA_CLOUD_ACCESS_KEY_SECRET");
         * 方式二：
         *     获取RAM用户AccessKey ID：System.getProperty("ALIBABA_CLOUD_ACCESS_KEY_ID");
         *     获取RAM用户AccessKey Secret：System.getProperty("ALIBABA_CLOUD_ACCESS_KEY_SECRET");
         */
        config.setAccessKeyId("建议从环境变量中获取RAM用户AccessKey ID");
        config.setAccessKeySecret("建议从环境变量中获取RAM用户AccessKey Secret");
        //接入区域和地址请根据实际情况修改
        config.setRegionId("cn-shanghai");
        config.setEndpoint("green-cip.cn-shanghai.aliyuncs.com");
        //读取时超时时间，单位毫秒（ms）。
        config.setReadTimeout(6000);
        //连接时超时时间，单位毫秒（ms）。
        config.setConnectTimeout(3000);
        //设置http代理。
        //config.setHttpProxy("http://xx.xx.xx.xx:xxxx");
        //设置https代理。
        //config.setHttpsProxy("https://xx.xx.xx.xx:xxxx");
        Client client = new Client(config);

        JSONObject serviceParameters = new JSONObject();
        serviceParameters.put("content", "测试文本内容");

        TextModerationPlusRequest textModerationPlusRequest = new TextModerationPlusRequest();
        // 检测类型
        textModerationPlusRequest.setService("comment_detection_pro");
        textModerationPlusRequest.setServiceParameters(serviceParameters.toJSONString());

        try {
            TextModerationPlusResponse response = client.textModerationPlus(textModerationPlusRequest);
            if (response.getStatusCode() == 200) {
                TextModerationPlusResponseBody result = response.getBody();
                System.out.println(JSON.toJSONString(result));
                System.out.println("requestId = " + result.getRequestId());
                System.out.println("code = " + result.getCode());
                System.out.println("msg = " + result.getMessage());
                Integer code = result.getCode();
                if (200 == code) {
                    TextModerationPlusResponseBody.TextModerationPlusResponseBodyData data = result.getData();
                    System.out.println(JSON.toJSONString(data, true));
                } else {
                    System.out.println("text moderation not success. code:" + code);
                }
            } else {
                System.out.println("response not success. status:" + response.getStatusCode());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
```

### Python SDK

支持Python 3.6及以上版本。

原始代码，请参见[Python SDK源码](https://pypi.org/project/alibabacloud-green20220302/)。

1、执行如下命令引入相关依赖。

```
pip install alibabacloud_green20220302==3.2.4
```

2、接入Python SDK 代码示例。

```
# coding=utf-8
# python version >= 3.6
from alibabacloud_green20220302.client import Client
from alibabacloud_green20220302 import models
from alibabacloud_tea_openapi.models import Config
import json

config = Config(
    # 阿里云账号AccessKey拥有所有API的访问权限，建议您使用RAM用户进行API访问或日常运维。
    # 强烈建议不要把AccessKey ID和AccessKey Secret保存到工程代码里，否则可能导致AccessKey泄露，威胁您账号下所有资源的安全。
    # 常见获取环境变量方式：
    # 获取RAM用户AccessKey ID：os.environ['ALIBABA_CLOUD_ACCESS_KEY_ID']
    # 获取RAM用户AccessKey Secret：os.environ['ALIBABA_CLOUD_ACCESS_KEY_SECRET']
    access_key_id='建议从环境变量中获取RAM用户AccessKey ID',
    access_key_secret='建议从环境变量中获取RAM用户AccessKey Secret',
    # 连接超时时间 单位毫秒(ms)
    connect_timeout=10000,
    # 读超时时间 单位毫秒(ms)
    read_timeout=3000,
    region_id='cn-hangzhou',
    endpoint='green-cip.cn-hangzhou.aliyuncs.com'
)

clt = Client(config)

serviceParameters = {
    'content': '测试文本内容'
}
textModerationPlusRequest = models.TextModerationPlusRequest(
    # 检测类型
    service='comment_detection_pro',
    service_parameters=json.dumps(serviceParameters)
)

try:
    response = clt.text_moderation_plus(textModerationPlusRequest)
    if response.status_code == 200:
        # 调用成功
        result = response.body
        print('response success. result:{}'.format(result))
    else:
        print('response not success. status:{} ,result:{}'.format(response.status_code, response))
except Exception as err:
    print(err)
```

### PHP SDK

支持PHP 5.6及以上版本。

原始代码，请参见[PHP SDK源码](https://packagist.org/packages/alibabacloud/green-20220302)。

1、执行如下命令引入相关依赖。

```
composer require alibabacloud/green-20220302 3.2.4
```

2、接入PHP SDK 代码示例。

```
<?php
require('vendor/autoload.php');

use AlibabaCloud\SDK\Green\V20220302\Models\TextModerationPlusRequest;
use AlibabaCloud\Tea\Exception\TeaUnableRetryError;
use Darabonba\OpenApi\Models\Config;
use AlibabaCloud\Tea\Utils\Utils\RuntimeOptions;
use AlibabaCloud\SDK\Green\V20220302\Green;

$config = new Config([
    /**
     * 阿里云账号AccessKey拥有所有API的访问权限，建议您使用RAM用户进行API访问或日常运维。
     * 强烈建议不要把AccessKey ID和AccessKey Secret保存到工程代码里，否则可能导致AccessKey泄露，威胁您账号下所有资源的安全。
     * 常见获取环境变量方式：
     * 获取RAM用户AccessKey ID：getenv("ALIBABA_CLOUD_ACCESS_KEY_ID");
     * 获取RAM用户AccessKey Secret：getenv("ALIBABA_CLOUD_ACCESS_KEY_SECRET");
     */
    "accessKeyId" => '建议从环境变量中获取RAM用户AccessKey ID',
    "accessKeySecret" => '建议从环境变量中获取RAM用户AccessKey Secret',
    // 设置HTTP代理。
    // "httpProxy" => "http://10.10.xx.xx:xxxx",
    // 设置HTTPS代理。
    // "httpsProxy" => "https://10.10.xx.xx:xxxx",
    "endpoint" => "green-cip.cn-shanghai.aliyuncs.com",
    "regionId" => "cn-shanghai"

]);
// 注意，此处实例化的client请尽可能重复使用，避免重复建立连接，提升检测性能。
$client = new Green($config);

$request = new TextModerationPlusRequest();
$request->service = "comment_detection_pro";
$serviceParameters = array("content" => "测试内容");

$request->serviceParameters = json_encode($serviceParameters);

$runtime = new RuntimeOptions();
$runtime->readTimeout = 6000;
$runtime->connectTimeout = 3000;

try {
    $response = $client->textModerationPlusWithOptions($request, $runtime);
    print_r($response->body);
    if (200 != $response->statusCode) {
        print_r("response not success. code:" . $response->statusCode);
        return;
    }
    $body = $response->body;
    print_r("requestId = " . $body->requestId . "\n");
    print_r("code = " . $body->code . "\n");
    print_r("message = " . $body->message . "\n");
    if (200 != $body->code) {
        print_r("text moderation not success. code:" . $body->code);
    }
    $data = $body->data;
    print_r("data = " . json_encode($data));
} catch (TeaUnableRetryError $e) {
    var_dump($e->getMessage());
    var_dump($e->getErrorInfo());
    var_dump($e->getLastException());
    var_dump($e->getLastRequest());
}
```

### Go SDK

1、执行如下命令引入相关依赖。

```
go get github.com/alibabacloud-go/green-20220302/v3@v3.2.4
```

2、接入Go SDK 代码示例。

```
package main

import (
	"encoding/json"
	"fmt"
	openapi "github.com/alibabacloud-go/darabonba-openapi/v2/client"
	green20220302 "github.com/alibabacloud-go/green-20220302/v3/client"
	util "github.com/alibabacloud-go/tea-utils/v2/service"
	"github.com/alibabacloud-go/tea/tea"
	"net/http"
)

func main() {
	// 工程代码泄露可能会导致AccessKey泄露，并威胁账号下所有资源的安全性。以下代码示例仅供参考，建议使用更安全的STS方式。
	config := &openapi.Config{
		/**
		 * 阿里云账号AccessKey拥有所有API的访问权限，建议您使用RAM用户进行API访问或日常运维。
		 * 强烈建议不要把AccessKey ID和AccessKey Secret保存到工程代码里，否则可能导致AccessKey泄露，威胁您账号下所有资源的安全。
		 * 常见获取环境变量方式：
		 * 获取RAM用户AccessKey ID：os.Getenv("ALIBABA_CLOUD_ACCESS_KEY_ID")
		 * 获取RAM用户AccessKey Secret：os.Getenv("ALIBABA_CLOUD_ACCESS_KEY_SECRET")
		 */
		AccessKeyId: tea.String("建议从环境变量中获取RAM用户AccessKey ID"),
		AccessKeySecret: tea.String("建议从环境变量中获取RAM用户AccessKey Secret"),
		// 设置HTTP代理。
		// HttpProxy: tea.String("http://xx.xx.xx.xx:xxxx"),
		// 设置HTTPS代理。
		// HttpsProxy: tea.String("https://username:password@xxx.xxx.xxx.xxx:9999"),
		RegionId: tea.String("cn-shanghai"),
		Endpoint: tea.String("green-cip.cn-shanghai.aliyuncs.com"),
		/**
		 * 请设置超时时间。服务端全链路处理超时时间为10秒，请做相应设置。
		 * 如果您设置的ReadTimeout小于服务端处理的时间，程序中会获得一个ReadTimeout异常。
		 */
		ConnectTimeout: tea.Int(3000),
		ReadTimeout: tea.Int(6000),
	}
	client, _err := green20220302.NewClient(config)
	if _err != nil {
		panic(_err)
	}

	// 创建RuntimeObject实例并设置运行参数。
	runtime := &util.RuntimeOptions{}
	runtime.ReadTimeout = tea.Int(10000)
	runtime.ConnectTimeout = tea.Int(10000)

	serviceParameters, _ := json.Marshal(
		map[string]interface{}{
			"content": "测试内容",
		},
	)
	request := green20220302.TextModerationPlusRequest{
		Service: tea.String("comment_detection_pro"),
		ServiceParameters: tea.String(string(serviceParameters)),
	}

	result, _err := client.TextModerationPlusWithOptions(&request, runtime)
	if _err != nil {
		panic(_err)
	}

	if *result.StatusCode != http.StatusOK {
		fmt.Printf("response not success. status:%d\n", *result.StatusCode)
		return
	}
	body := result.Body
	fmt.Printf("response success. requestId:%s, code:%d, msg:%s\n", *body.RequestId, *body.Code, *body.Message)
	if *body.Code != http.StatusOK {
		fmt.Printf("text moderation not success. code:%d\n", *body.Code)
		return
	}

	data := body.Data
	fmt.Printf("text moderation data:%s\n", *data)
}
```

### Node.js SDK

原始代码，请参见[Node.js SDK源码](https://www.npmjs.com/package/@alicloud/green20220302)。

1、执行如下命令引入相关依赖。

```
npm install @alicloud/green20220302@3.2.4
```

2、接入Node.js SDK 代码示例。

```
const Green20220302 = require('@alicloud/green20220302');
const OpenApi = require('@alicloud/openapi-client');
const Util = require('@alicloud/tea-util');
// 注意：此处实例化的client尽可能重复使用，提升检测性能。避免重复建立连接。
// 工程代码泄露可能会导致 AccessKey 泄露，并威胁账号下所有资源的安全性。以下代码示例仅供参考。
class Client {
    static createClient() {
        const config = new OpenApi.Config({
            // 必填，请确保代码运行环境设置了环境变量 ALIBABA_CLOUD_ACCESS_KEY_ID。
            accessKeyId: process.env['ALIBABA_CLOUD_ACCESS_KEY_ID'],
            // 必填，请确保代码运行环境设置了环境变量 ALIBABA_CLOUD_ACCESS_KEY_SECRET。
            accessKeySecret: process.env['ALIBABA_CLOUD_ACCESS_KEY_SECRET'],
            endpoint: `green-cip.cn-shanghai.aliyuncs.com`,
        });
        return new Green20220302.default(config);
    }

    static async main() {
        const client = Client.createClient();
        // 构造请求对象
        const textModerationPlusRequest = new Green20220302.TextModerationPlusRequest({
            // 文本增强版plus检测service，参考：https://help.aliyun.com/document_detail/2684669.html#p-t7m-66g-cv6。
            "service": "comment_detection_pro",
            "serviceParameters": JSON.stringify({
                // 待检测文本。 
                "content": "测试文本"})
            });
        // 创建运行时配置对象
        const runtime = new Util.RuntimeOptions();
        try {
            // 发起请求并获取响应
            const response = await client.textModerationPlusWithOptions(textModerationPlusRequest, runtime);
            console.log(JSON.stringify(response.body));
        } catch (error) {
            // 此处仅做打印展示，请谨慎对待异常处理，在工程项目中切勿直接忽略异常。
            // 错误 message
            console.log('Error occurred:', error.message);
        }
    }
}

Client.main();
```

### C# SDK

原始代码，请参见[C# SDK源码](https://www.nuget.org/packages/AlibabaCloud.SDK.Green20220302/)。

1、执行如下命令引入相关依赖。

```
dotnet add package AlibabaCloud.SDK.Green20220302 --version 3.2.4
```

2、接入C# SDK 代码示例。

```
// This file is auto-generated, don't edit it. Thanks.

using Newtonsoft.Json;

namespace AlibabaCloud.SDK.Green20220302
{
    public class TextModerationPlusAutoRoute
    {
        public static void Main(string[] args)
        {
            /**
            * 阿里云账号AccessKey拥有所有API的访问权限，建议您使用RAM用户进行API访问或日常运维。
            * 强烈建议不要把AccessKey ID和AccessKey Secret保存到工程代码里，否则可能导致AccessKey泄露，威胁您账号下所有资源的安全。
            * 常见获取环境变量方式：
            * 获取RAM用户AccessKey ID：Environment.GetEnvironmentVariable("ALIBABA_CLOUD_ACCESS_KEY_ID")
            * 获取RAM用户AccessKey Secret：Environment.GetEnvironmentVariable("ALIBABA_CLOUD_ACCESS_KEY_SECRET")
            */
            String accessKeyId = "建议从环境变量中获取RAM用户AccessKey ID";
            String accessKeySecret = "建议从环境变量中获取RAM用户AccessKey Secret";
            // 接入区域和地址请根据实际情况修改
            String endpoint = "green-cip.cn-shanghai.aliyuncs.com";
            //注意，此处实例化的client请尽可能重复使用，避免重复建立连接，提升检测性能。
            Client client = createClient(accessKeyId, accessKeySecret, endpoint);

            // 运行时参数设置，仅对使用了该运行时参数实例的请求有效
            AlibabaCloud.TeaUtil.Models.RuntimeOptions runtimeOptions =
                new AlibabaCloud.TeaUtil.Models.RuntimeOptions();

            //构建文本检测请求。
            Models.TextModerationPlusRequest textModerationPlusRequest =
                new Models.TextModerationPlusRequest();
            //文本Plus检测service示例：nickname_detection_pro
          	//支持service请参考：https://help.aliyun.com/document_detail/2684669.html#p-t7m-66g-cv6
          	textModerationPlusRequest.Service = "nickname_detection_pro";
            Dictionary<string, object> task = new Dictionary<string, object>();
            task.Add(
                "content",
                "测试文本"
            );

            textModerationPlusRequest.ServiceParameters = JsonConvert.SerializeObject(task);

            try
            {
                //调用API获取检测结果。
                Models.TextModerationPlusResponse response = client.TextModerationPlusWithOptions(
                    textModerationPlusRequest,
                    runtimeOptions
                );
                //自动路由，区域切换至cn-beijing。
                if (
                    response is null
                    || response.Body is null
                    || AlibabaCloud.TeaUtil.Common.EqualNumber(
                        500,
                        AlibabaCloud.TeaUtil.Common.AssertAsNumber(response.StatusCode)
                    )
                    || AlibabaCloud.TeaUtil.Common.EqualString(
                        "500",
                        Convert.ToString(response.Body.Code)
                    )
                )
                {
                    endpoint = "green-cip.cn-beijing.aliyuncs.com";
                    client = createClient(accessKeyId, accessKeySecret, endpoint);
                    response = client.TextModerationPlusWithOptions(
                        textModerationPlusRequest,
                        runtimeOptions
                    );
                }

                Console.WriteLine(response.Body.RequestId);
                Console.WriteLine(JsonConvert.SerializeObject(response.Body));
            }
            catch (Exception _err)
            {
                Console.WriteLine(_err);
            }
        }

        //创建请求客户端
        public static Client createClient(
            String accessKeyId,
            String accessKeySecret,
            String endpoint
        )
        {
            AlibabaCloud.OpenApiClient.Models.Config config =
                new AlibabaCloud.OpenApiClient.Models.Config
                {
                    AccessKeyId = accessKeyId,
                    AccessKeySecret = accessKeySecret,
                    //设置HTTP代理。
                    //HttpProxy = "http://10.10.xx.xx:xxxx",
                    //设置HTTPS代理。
                    //HttpsProxy = "https://username:password@xxx.xxx.xxx.xxx:9999",
                    //访问的域名。
                    Endpoint = endpoint,
                };
            return new Client(config);
        }
    }
}
```

### **HTTPS原生调用**

内容安全增强版API服务也支持HTTPS原生调用，原生方式需要用户自行封装加解签、拼装请求（URL、Body、header、parameters）。通常必须使用HTTPS原生方式调用的仅有两种情形，如非下述两种特殊场景，建议使用SDK方式调用。

1.  直接在App中使用，对客户端大小有高要求。
    
2.  对个别的依赖lib包有指定，不方便升级。
    

-   **调用方式**
    
    服务请求地址：https://green-cip.{region}.aliyuncs.com
    
    协议：HTTPS
    
    方式：POST
    
-   **公共请求参数**
    
    文本审核增强版API接口的入参包含公共请求参数和具体接口请求参数，公共请求参数是指每一个接口都需要使用到的参数，以下表格是公共请求参数的详细介绍。
    
    | **名称** | **类型** | **是否必须** | **描述** |
    | --- | --- | --- | --- |
    | Format | String | 是   | 返回消息的格式。取值： - JSON （默认值） - XML |
    | Version | String | 是   | API版本号，使用YYYY-MM-DD日期格式，本版本对应为2022-03-02。 |
    | AccessKeyId | String | 是   | 阿里云颁发给用户的访问服务所用的密钥ID。 |
    | Signature | String | 是   | 签名结果串，关于签名的计算方法，请参见下方签名方式。 |
    | SignatureMethod | String | 是   | 签名方式，目前支持HMAC-SHA1。 |
    | Timestamp | String | 是   | 请求的时间戳。日期格式按照ISO8601标准表示，并需要使用UTC时间。格式为：yyyy-MM-ddTHH:mm:ssZ。例如，北京时间2022年12月12日09点13分14秒表示为2022-12-12T01:13:14Z。 |
    | SignatureVersion | String | 是   | 签名算法版本，取值为1.0。 |
    | SignatureNonce | String | 是   | 唯一随机数，用于防止网络重放攻击。不同请求要使用不同的随机数值。 |
    | Action | String | 是   | - 文本增强版Plus接口：TextModerationPlus |
    
-   **公共返回参数**
    
    您发送的每次接口调用请求，无论成功与否，系统都会返回唯一识别码RequestId。其他返回参数包含label（标签）、confidence（置信分值），服务不同返回的参数不同，详见具体服务对应的文档。
    
-   **代码示例**
    
    以下返回示例为了便于阅读，做了格式化处理，实际返回结果没有进行换行、缩进等格式化处理。
    
    以下是**文本审核****增强版****\-****用户昵称检测\_专业版**的请求示例，其他接口请参考具体接口文档获取业务入参：
    
    ```
    https://green-cip.cn-shanghai.aliyuncs.com/
        ?Format=JSON
        &Version=2022-03-02
        &Signature=vpEEL0zFHfxXYzSFV0n7%2FZiFL9o%3D
        &SignatureMethod=Hmac-SHA1
        &SignatureNonce=15215528852396
        &SignatureVersion=1.0
        &Action=TextModerationPlus
        &AccessKeyId=123****cip
        &Timestamp=2022-12-12T12:00:00Z
        &Service=nickname_detection_pro
        &ServiceParameters={"content": "测试文本"}
    ```
    
    以下是**文本审核****增强版****\-****用户昵称检测\_专业版**返回参数的JSON代码示例：
    
    ```
    {
        "Code": 200,
        "Data": {
            "Result": [
                {
                    "Label": "political_entity",
                    "Description":"疑似政治实体",
                    "Confidence": 100.0,
                    "RiskWords": "词A,词B,词C"
                },
                {
                    "Label": "political_figure",
                    "Description":"疑似政治人物",
                    "Confidence": 100.0,
                    "RiskWords": "词A,词B,词C"
                }
            ],
            "RiskLevel": "high"
        },
        "Message": "OK",
        "RequestId": "AAAAAA-BBBB-CCCCC-DDDD-EEEEEEEE****"
    }
    ```
    
-   **签名方式**
    
    文本审核增强版服务会对每个访问的请求进行身份验证，因此，需要在请求中包含签名（Signature）信息。文本审核增强版服务通过使用AccessKey ID和AccessKey Secret进行对称加密的方法来验证请求的发送者身份。
    
    AccessKey ID和AccessKey Secret由阿里云官方颁发给访问者（可以通过阿里云官方网站申请和管理），其中AccessKey ID用于标识访问者身份；AccessKey Secret是用于加密签名字符串和服务器端验证签名字符串的密钥，必须严格保密，只有阿里云和用户知道。
    
    用户在访问时，按照下面的方法对请求进行签名处理：
    
    1.  使用请求参数构造规范化的请求字符串（Canonicalized Query String）。
        
        1.  按照参数名称的字典顺序对请求中所有的请求参数（包括公共请求参数和给定了的请求接口的自定义参数，但不能包括公共请求参数中提到的**Signature**参数本身）进行排序。
            
        2.  对相关请求参数的名称和值进行编码。名称和值要使用UTF-8字符集进行URL编码。
            
            **说明**
            
            一般支持URL编码的库（比如Java中的java.net.URLEncoder）都是按照application/x-www-form-urlencoded的MIME类型的规则进行编码的。实现时可以直接使用这类方式进行编码，把编码后的字符串中加号（+）替换成%20、星号（\*）替换成%2A、%7E替换回波浪号（~），即可得到上述规则描述的编码字符串。
            
            URL编码的编码规则如下：
            
            -   对于字符A-Z、a-z、0-9以及字符中划线（-）、下划线（\_）、半角句号（.）、波浪线（~）不编码。
                
            -   对于其它字符编码成`%XY`的格式，其中XY是字符对应ASCII码的16进制表示。比如英文的双引号（"）对应的编码就是`%22`。
                
            -   对于扩展的UTF-8字符，编码成`%XY%ZA…`的格式。
                
            -   需要说明的是英文空格（ ）要被编码是`%20`，而不是加号（+）。
                
            
        3.  对编码后的参数名称和值使用英文等号（=）进行连接。
            
        4.  将英文等号连接得到字符串按参数名称的字典顺序依次使用&符号连接，即得到规范化请求字符串。
            
    2.  使用a.i构造的规范化字符串按照下面的规则构造用于计算签名的字符串。
        
        ```
        StringToSign=
        HTTPMethod + "&" +
        percentEncode（"/"） + "&" +
        percentEncode（CanonicalizedQueryString）
        ```
        
        **说明**
        
        其中HTTPMethod是提交请求用的HTTP方法，比如POST。percentEncode（/）是按照a.ii中描述的URL编码规则对字符（/）进行编码得到的值，即`%2F`。percentEncode（CanonicalizedQueryString）是对a.i中构造的规范化请求字符串按a.ii中描述的URL编码规则编码后得到的字符串。
        
    3.  按照RFC2104的定义，使用上面的用于签名的字符串计算签名HMAC值。
        
        **说明**
        
        注意计算签名时使用的Key就是用户持有的AccessKey Secret并加上一个`&`字符（ASCII:38），使用的哈希算法是SHA1。
        
    4.  按照Base64编码规则把上面的HMAC值编码成字符串，即得到签名值（Signature）。
        
    5.  将得到的签名值作为Signature参数添加到请求参数中，即完成对请求签名的过程。
        
        **说明**
        
        得到的签名值在作为最后的请求参数值提交给内容安全服务器时，要和其他参数一样，按照RFC3986的规则进行URL编码。
        

如果您在使用过程中出现问题，可以请加入钉群（钉群号：35573806），联系产品技术专家进行咨询。