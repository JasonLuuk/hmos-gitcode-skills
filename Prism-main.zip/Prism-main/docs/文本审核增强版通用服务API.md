本文介绍了调用文本审核增强版接口审核文本内容的方法。

**重要**

文本审核增强版推出标签更丰富、配置更灵活的PLUS版本服务，推荐您首选接入[文本审核增强版PLUS服务](https://help.aliyun.com/zh/document_detail/2684669.html)。

## 使用说明

您可以调用该接口创建文本内容检测任务。关于如何构造HTTP请求，请参见[HTTPS原生调用](https://help.aliyun.com/zh/document_detail/467828.html#065ca2b17cclu)；您也可以直接选用已构造好的HTTP请求，更多信息，请参见[接入指南](https://help.aliyun.com/zh/document_detail/2933065.html)。

您可以在[OpenAPI Explorer](https://next.api.aliyun.com/api/Green/2022-03-02/TextModeration?lang=JAVA)中直接运行该接口，免去您计算签名的困扰。运行成功后，[OpenAPI Explorer](https://next.api.aliyun.com/api/Green/2022-03-02/TextModeration?lang=JAVA)可以自动生成SDK代码示例。

-   **业务接口：**TextModeration

-   **支持的地域及接入地址**：

    | **地域** | **外网接入地址** | **内网接入地址** |
        | --- | --- | --- |
    | 华东2（上海） | https://green-cip.cn-shanghai.aliyuncs.com | https://green-cip-vpc.cn-shanghai.aliyuncs.com |
    | 华北2（北京） | https://green-cip.cn-beijing.aliyuncs.com | https://green-cip-vpc.cn-beijing.aliyuncs.com |
    | 华东1（杭州） | https://green-cip.cn-hangzhou.aliyuncs.com | https://green-cip-vpc.cn-hangzhou.aliyuncs.com |
    | 华南1（深圳） | https://green-cip.cn-shenzhen.aliyuncs.com | https://green-cip-vpc.cn-shenzhen.aliyuncs.com |
    | 西南1（成都） | https://green-cip.cn-chengdu.aliyuncs.com | 暂无  |

-   **计费信息**：

    该接口为收费接口。仅对HTTP状态码为200的请求进行计量计费，产生其他错误码时不会计费。关于计费方式，请参见[计费说明](https://help.aliyun.com/zh/document_detail/433938.html#task-2223879)。


## QPS限制

本接口的单用户QPS限制为100次/秒。超过限制，API调用会被限流，这可能会影响您的业务，请合理调用。

## 请求参数

| **名称** | **类型** | **是否必须** | **示例值** | **描述** |
| --- | --- | --- | --- | --- |
| **Service** | String | 是   | nickname\\_detection | 审核服务类型，包括： - **nickname\\_detection**：用户昵称检测 - **chat\\_detection**：私聊互动内容检测 - **comment\\_detection**：公聊评论内容检测 - **ai\\_art\\_detection**：AIGC文字检测 - **ad\\_compliance\\_detection**：广告法合规检测 - **pgc\\_detection**：PGC教学物料检测 |
| **ServiceParameters** | JSONString | 是   |     | 审核服务需要的参数集。JSON字符串格式，关于每个字符串的描述，请参见[ServiceParameters](#table-3ji-jc0-y0o)。 |

表 1. ServiceParameters

| **名称** | **类型** | **是否必须** | **示例值** | **描述** |
| --- | --- | --- | --- | --- |
| **content** | String | 是   | 检测内容 | 审核的文本内容，限定在600字符以内。 |
| **accountId** | String | 否   | 10123\\*\\*\\*\\* | 账户ID，标识一个账户的唯一ID。 |
| **deviceId** | String | 否   | 20240307\\*\\*\\*\\* | 设备ID，标识一个设备的唯一ID。 |
| **deviceToken** | String | 否   | MzQvo1d7scyZ3tl\\_RcJ\\*\\*\\*\\*\\*\\* | 通过风险控制SDK获取到的设备令牌。 |

## 返回参数

| **名称** | **类型** | **示例值** | **描述** |
| --- | --- | --- | --- |
| **Code** | Integer | 200 | 状态码。更多信息，请参见[Code说明](#section-25m-e97-xsj)。 |
| **Data** | JSONObject |     | 审核结果数据。更多信息，请参见[Data](#81f3f752ec6pa)。 |
| **Message** | String | OK  | 请求消息的响应消息。 |
| **RequestId** | String | AAAAAA-BBBB-CCCCC-DDDD-EEEEEEEE\\*\\*\\*\\* | 请求ID。 |

表 2. Data

| **名称** | **类型** | **示例值** | **描述** |
| --- | --- | --- | --- |
| **Labels** | String | sexual\\_content | 标签，多个用英文逗号分隔。包括： - **ad**：广告引流 - **political\\_content**：涉政内容 - **profanity**：辱骂内容 - **contraband**：违禁内容 - **sexual\\_content**：色情内容 - **violence**：暴恐内容 - **nonsense**：无意义内容 - **negative\\_content**：不良内容 - **religion**：宗教内容 - **cyberbullying**：网络暴力 - **ad\\_compliance**：广告法合规 - **C\\_customized**：用户库命中 **说明** 标签会持续新增，建议业务对接过程对未知标签忽略处理。 |
| **Reason** | String | {\\\\"riskLevel\\\\":\\\\"high\\\\",\\\\"riskTips\\\\":\\\\"色情\\_低俗词\\\\",\\\\"riskWords\\\\":\\\\"色情服务\\\\"} | 原因定位的JSON字符串，包含以下字段： - **riskLevel**：风险等级，根据系统推荐的风险等级返回，返回值包括： - high：高风险 - medium：中风险 - low：低风险 **说明** 高风险内容建议直接处置；中风险内容建议人工复查；低风险内容建议在高召回需求时再做处理，日常建议和未检测到风险做相同处理。 - **riskTips**：细分标签 - **riskWords**：命中风险内容 - **customizedWords**：命中用户词 - **customizedLibs**：命中用户词库名 |
| **AccountId** | String | 10123\\*\\*\\*\\* | 账户ID。 **说明** 如果在检测请求参数中传入了accountId，则此处返回对应的accountId。 |
| **DeviceId** | String | 20240307\\*\\*\\*\\* | 设备ID。 **说明** 如果在检测请求参数中传入了deviceId，则此处返回对应的deviceId。 |

## 示例

请求示例

```
{
    "Service": "nickname_detection",
    "ServiceParameters": {
        "content": "检测内容",
        "accountId": "10123****"
    }
}
```

返回示例：

命中系统策略：

```
{
    "Code": 200,
    "Data": {
        "Labels": "sexual_content",
        "Reason": "{\"riskLevel\":\"high\",\"riskTips\":\"色情_低俗词\",\"riskWords\":\"色情服务\"}",
        "AccountId": "10123****"
    },
    "Message": "OK",
    "RequestId": "AAAAAA-BBBB-CCCCC-DDDD-EEEEEEEE****"
}
```

命中自定义关键词：

```
{
    "Code": 200,
    "Data": {
        "Labels": "sexual_content",
        "Reason": "{\"riskLevel\":\"high\",\"customizedWords\":\"自定义关键词\",\"customizedLibs\":\"自定义关键词库名称\"}",
        "AccountId": "10123****"
    },
    "Message": "OK",
    "RequestId": "AAAAAA-BBBB-CCCCC-DDDD-EEEEEEEE****"
}
```

## Code说明

| **Code** | **响应信息** | **说明** |
| --- | --- | --- |
| 200 | OK  | 请求成功。 |
| 400 | BAD\\_REQUEST | 请求有误。原因：可能是请求参数不正确导致，请仔细检查请求参数。 |
| 408 | PERMISSION\\_DENY | 原因：可能是您的账号未授权、账号欠费、账号未开通、账号被禁等。 |
| 500 | GENERAL\\_ERROR | 错误。原因：可能是服务端临时出错。建议重试，若持续返回该错误码，请通过[在线服务](https://smartservice.console.aliyun.com/service/robot-chat?spm=0.b82045537.0.0.148bzEhAzEhAyF)联系我们。 |
| 581 | TIMEOUT | 超时。建议重试，若持续返回该错误码，请通过[在线服务](https://smartservice.console.aliyun.com/service/robot-chat?spm=0.b82045537.0.0.148bzEhAzEhAyF)联系我们。 |
| 588 | EXCEED\\_QUOTA | 请求频率超出配额。 |