# Evolution.md - AI_Chat2 开发经验沉淀

> **版本**: v1.1
> **创建日期**: 2026-04-28
> **用途**: 记录已验证的开发难点和解决方案，构建失败时优先查阅

---

## 1. 项目初始化经验

### 1.1 MVVM 目录结构初始化

**验证日期**: 2026-04-28
**构建状态**: ✅ 通过

**目录结构创建要点**:
- 仓颉编译器对目录结构无强制要求，但需遵循 MVVM 分层规范
- 包命名必须与目录路径一致：`ohos_app_cangjie_entry.{子目录路径}`
- 每个模块包含完整分层：model/view_model/view/pages/business/shared/repository/service
- `view/` 目录下需创建 3 个子目录：pages(页面)、business(业务组件)、shared(共享组件)

**目录数量统计**:
| 层级 | 数量 |
|------|------|
| common 子目录 | 4 |
| core 子目录 | 3 |
| features 模块 | 8 × 7 = 56 |
| app 子目录 | 5 |
| theme | 1 |
| test 子目录 | 3 |
| **总计** | **72** |

### 1.2 UI 资源变量化

**验证日期**: 2026-04-28
**构建状态**: ✅ 通过

**Theme.cj 定义要点**:
- 使用 `public class + static let` 定义常量（**object 内部不支持 public const**）
- 颜色值使用 `Color(0xFF...)` 格式
- Float 类型需指定后缀：`Float32` 用 `.f32` 或直接写数值，`Float64` 用 `.f64`
- 禁止在 View 层硬编码颜色、圆角、间距值

**正确示例**:
```cangjie
public class AppColors {
    public static let PAGE_BG = Color(0xFF0F0A1E)
}

public class AppFontSize {
    public static let PAGE_TITLE_LARGE: Float32 = 28.0
}
```

**错误示例（已修正）**:
```cangjie
public const AppColors = object {
    public const PAGE_BG = Color(0xFF0F0A1E)  // ❌ object 内不支持 public const
}
```

### 1.3 ArkUI 组件开发规范

**验证日期**: 2026-04-28
**构建状态**: ✅ 通过

**EntryView.cj 关键要点**:
- 导入必须使用通配符：`import kit.ArkUI.*` 和 `import ohos.arkui.state_macro_manage.*`
- 尺寸值使用 `.vp` 单位：`.fontSize(28.vp)` 而非 `.fontSize(28.0f32)`
- `@Entry` + `@Component` 装饰器组合用于页面入口
- 类必须声明为 `public` 才能跨包导入

**正确示例**:
```cangjie
import kit.ArkUI.*
import ohos.arkui.state_macro_manage.*

@Entry
@Component
public class EntryView {
    @State var message: String = "AI Chat App"
    
    func build() {
        Column() {
            Text(this.message).fontSize(28.vp).fontWeight(FontWeight.Bold)
        }
    }
}
```

### 1.4 包导入规范

**验证日期**: 2026-04-28
**构建状态**: ✅ 通过

**关键要点**:
- 包名必须与目录路径完全一致
- 跨包导入必须使用 `import 包名.类名` 或 `import 包名.*`
- 自动生成的 `ability_mainability_entry.cj` 需手动添加 import

**示例**:
```cangjie
// app/view/EntryView.cj
package ohos_app_cangjie_entry.app.view
import ohos_app_cangjie_entry.theme.AppColors  // 导入具体类

// app/ability/MainAbility.cj
package ohos_app_cangjie_entry.app.ability
public class MainAbility <: UIAbility { ... }  // 必须声明 public

// ability_mainability_entry.cj（自动生成）
import ohos_app_cangjie_entry.app.ability.MainAbility  // 必须添加
```

---

## 2. 已验证经验

### 2.1 编译器兼容性

**验证状态**: ✅ 通过

**结论**: MVVM 目录结构完全满足仓颉编译器要求，只需确保：
1. 包名与目录路径一致
2. 跨包类声明为 `public`
3. 正确使用 import 语句

### 2.2 包命名规范

**验证状态**: ✅ 通过

**结论**: 仓颉要求分层包名，格式为 `ohos_app_cangjie_entry.{子目录路径}`

### 2.3 Float 类型后缀

**验证状态**: ✅ 通过

**结论**: 仓颉 Float 后缀只能是 `f16`/`f32`/`f64`，不能用单独的 `f`

---

## 3. 已知风险点与解决方案

### 3.1 包找不到错误

**错误**: `can not find the following dependencies`
**原因**: import 语句引用了不存在或不公开的类
**解决**:
1. 确保目标类声明为 `public`
2. 确保 import 路径与包名一致
3. 检查自动生成文件是否缺少 import

### 3.2 Float 后缀错误

**错误**: `illegal float number suffix 'f'`
**原因**: 仓颉不支持单独的 `f` 后缀
**解决**: 使用 `f16`/`f32`/`f64` 或直接写数值（如 `28.0`）

### 3.3 object 内 public const 错误

**错误**: `unexpected modifier 'public' on variable declaration in block`
**原因**: object 定义内部成员不支持 `public const` 修饰符
**解决**: 使用 `public class + static let` 替代 object 定义

---

## 4. 初始化后项目结构

**已验证的简化版结构**（构建通过）:
```
entry/src/main/cangjie/
├── app/
│   ├── ability/MainAbility.cj (public class)
│   ├── model/AppState.cj
│   ├── view/EntryView.cj (@Entry @Component)
│   ├── DependencyBootstrap.cj
│   └── AppStateBootstrap.cj
├── theme/Theme.cj (public class 定义)
├── index.cj
├── main_ability.cj
├── ability_mainability_entry.cj (已添加 import)
└── features/ (空目录，后续填充)
```

---

**更新规则**:
- 构建成功后补充验证经验
- 构建失败时优先查阅本文档匹配已有解决方案
- 禁止写入未验证方案

---

## 13. API 版本兼容性适配（2026-05-12）

### 13.1 从 API 23 降级兼容 API 22

- **验证状态**: ✅ 构建通过
- **需求场景**: 应用需同时支持 API 22 (HarmonyOS 6.0.2) 和 API 23 (HarmonyOS 6.1.0) 设备
- **适配方案**:
  1. 修改 `build-profile.json5` 的 `compatibleSdkVersion` 为 `6.0.2(22)`
  2. 保持 `targetSdkVersion` 为 `6.1.0(23)`（使用最新 SDK 编译）
- **代码无需改动的原因**:
  - `launch()` 起始版本 22 → 线程调度兼容
  - `AppStorage` 起始版本 22 → 全局状态兼容
  - `Preferences` 起始版本 22 → 持久化兼容
  - `createHttp()` 起始版本 22 → HTTP 请求兼容
  - `terminateSelf()` 起始版本 22 → 退出应用兼容
  - `getUIContext().animateTo()` 起始版本 22 → 动画兼容
- **关键修改**:
  ```json5
  // build-profile.json5
  {
    "app": {
      "products": [{
        "targetSdkVersion": "6.1.0(23)",
        "compatibleSdkVersion": "6.0.2(22)"  // 修改此处
      }]
    }
  }
  ```
- **关键词**: compatibleSdkVersion, API 22, API 23, 版本兼容, 起始版本 22

---

## 5. Profile模块开发经验（2026-04-28）

### 5.1 @Observed装饰器使用限制

- **错误类型**: 编译错误
- **错误信息**:
  ```
  error: macro evaluation has failed for macro call 'Observed'
  ```
- **原因分析**: @Observed装饰器只能用于UI组件（@Component），不能用于Model层的普通类或ViewModel层。Model层应该使用普通class定义，ViewModel层也应该使用普通class（除非需要响应式刷新）。
- **解决方案**:
  1. Model层（UserProfile等）使用普通class，不添加@Observed和@Publish
  2. ViewModel层（ProfileViewModel等）使用普通class，不添加@Observed和@Publish
  3. 只有UI组件（@Component）才使用@Observed和@Publish
- **正确代码示例**:
  ```cangjie
  // Model层 - 普通class
  public class UserProfile {
      public var userName: String = "用户"
      public var userAvatarColor: Int64 = 0xFF8B5CF6
      public init() {}
  }
  
  // ViewModel层 - 普通class
  public class ProfileViewModel {
      public var userProfile: UserProfile = UserProfile()
      public init() {}
  }
  
  // View层 - @Component + @State/@Link
  @Component
  public class SettingsPanel {
      @State var editUserName: String = ""
      @Link var userName: String
  }
  ```
- **关键词**: @Observed, @Publish, Model层, ViewModel层, macro evaluation failed

### 5.2 build方法中禁止使用for循环

- **错误类型**: 编译错误
- **错误信息**:
  ```
  error: Only UI component syntax can be written in build method. 
  for(color in ...) does not meet UI component.
  ```
- **原因分析**: ArkUI的build方法中不能使用普通的for循环来创建组件。必须使用ForEach组件或@Builder方法。

---

## 6. 架构收敛经验（2026-04-29）

### 6.1 EntryView 业务下沉（消息状态）

- **验证状态**: ✅ 构建通过
- **改动摘要**:
  - 新增 `features/message/service/IMessageStateService.cj`
  - 新增 `features/message/service/MessageStateServiceImpl.cj`
  - 新增 `features/message/model/MessageListState.cj`
  - 新增 `features/message/repository/IMessageStateRepository.cj`
  - 新增 `features/message/repository/MessageStateRepositoryImpl.cj`
  - `EntryView` 的未读/置顶状态计算改为调用 `MessageStateServiceImpl`
- **经验结论**:
  - 将列表状态逻辑从 View 下沉到 Service，可以减少 UI 侧业务分支，提升可测试性。
  - 即使暂未完全切换到 AppViewModel，也应优先把“纯业务规则”抽离出页面文件。

### 6.2 MVVM完成度评估方法

- **验证状态**: ✅ 可复用
- **检查口径**:
  - 对每个 `features/*` 目录检查是否具备 `model/view_model/view/repository/service`
  - 统计超长文件（建议 > 500 行重点治理）
- **当前发现**:
  - 仍有多个模块缺层，`EntryView.cj` 和 `GroupDataCatalog.cj` 为主要超长文件。
  - 文档已同步记录“当前落地状态”和后续收敛优先级。
- **解决方案**:
  1. 使用@Builder方法创建单个组件模板
  2. 在build方法中直接调用@Builder方法多次（硬编码）
  3. 或使用ForEach组件遍历数组
- **正确代码示例**:
  ```cangjie
  // 方法1: 使用@Builder方法
  @Builder
  private func buildColorItem(color: Int64, marginRight: Float64, marginTop: Float64) {
      Row() {
          Text(if (this.editUserAvatarColor == color) { "✓" } else { "" })
      }
      .width(36).height(36).backgroundColor(color)
  }
  
  // 在build方法中调用
  Row() {
      this.buildColorItem(0xFF8B5CF6, 8.0, 0.0)
      this.buildColorItem(0xFFE53935, 8.0, 0.0)
      // ...
  }
  ```
- **关键词**: for循环, build方法, @Builder, ForEach, UI component syntax

### 5.3 @Builder方法参数类型规范

- **错误类型**: 编译错误
- **原因分析**: @Builder方法的参数类型应该使用原始类型（Int64, Float64, String等），而不是ObservedProperty类型。编译器会自动处理参数传递。
- **解决方案**: @Builder方法参数直接使用原始类型
- **正确代码示例**:
  ```cangjie
  @Builder
  private func buildColorItem(color: Int64, marginRight: Float64, marginTop: Float64) {
      // 参数使用原始类型
  }
  ```
- **关键词**: @Builder, 参数类型, ObservedProperty

### 5.4 资源引用@r宏未声明__GenerateResource__

- **错误类型**: 编译错误
- **错误信息**:
  ```
  error: undeclared identifier '__GenerateResource__'
  ```
- **原因分析**: 使用 `@r(app.media.xxx)` 引用资源时，需要导入 `kit.LocalizationKit.*` 模块才能正确展开资源宏。
- **解决方案**: 在使用 `@r()` 资源引用的文件中添加以下导入：
  ```cangjie
  import kit.LocalizationKit.*
  import ohos.resource_manager.*
  import ohos.resource.*
  ```
- **关键词**: @r, __GenerateResource__, 资源引用, LocalizationKit

### 5.5 ability_mainability_entry.cj缺少导入

- **错误类型**: 编译错误
- **错误信息**:
  ```
  error: undeclared identifier 'MainAbility'
  ```
- **原因分析**: 自动生成的 `ability_mainability_entry.cj` 文件中引用了 `MainAbility` 类，但未添加导入语句。
- **解决方案**: 在 `ability_mainability_entry.cj` 中添加导入：
  ```cangjie
  import ohos_app_cangjie_entry.app.ability.MainAbility
  ```
- **关键词**: MainAbility, ability_mainability_entry, 导入

---

## 6. Home模块开发经验（2026-04-28）

### 6.1 Group类构造函数参数数量问题

- **错误类型**: 编译错误
- **错误信息**:
  ```
  error: extra arguments given for parameter list '(Int64, Struct-String, Struct-String, Class-ArrayList<Class-GroupMember>, Bool, Struct-String, Struct-String)' in call
  expected 7 arguments, found 10
  ```
- **原因分析**: Group.cj 中只有7个参数的构造函数，但 GroupDataRepository.cj 调用时传递了10个参数（包含 lastTimestamp, category, icon）。
- **解决方案**: 在 Group.cj 中添加新的构造函数支持10个参数：
  ```cangjie
  public init(id: Int64, name: String, description: String, members: ArrayList<GroupMember>, 
              isPreset: Bool, lastMessage: String, lastTime: String, lastTimestamp: Int64, 
              category: String, icon: String) {
      this.id = id
      this.name = name
      // ... 其他赋值
      this.lastTimestamp = lastTimestamp
      this.category = category
      this.icon = icon
  }
  ```
- **关键词**: Group, 构造函数, 参数数量, extra arguments

### 6.2 Service层缺少Model导入

- **错误类型**: 编译错误
- **错误信息**:
  ```
  error: undeclared type name 'Message'
  ```
- **原因分析**: SearchServiceImpl.cj 使用了 Message 类型，但未导入对应的包。
- **解决方案**: 在 Service 文件开头添加 Model 层导入：
  ```cangjie
  import ohos_app_cangjie_entry.features.group.model.Message
  ```
- **关键词**: Message, undeclared type, Service层导入

### 6.3 for循环中break的特殊处理

- **错误类型**: 编译错误
- **错误信息**:
  ```
  error: unclosed delimiter: '{'
  for (group in this.groups) {
      if (group.id == result.groupId) { this.enterChat(group); break }
  })
  ```
- **原因分析**: 仓颉中 for 循环内不能直接使用 break，需要使用标志变量控制循环退出。
- **解决方案**: 使用标志变量替代 break：
  ```cangjie
  .onClick({_ =>
      var found: Bool = false
      for (group in this.groups) {
          if (group.id == result.groupId) {
              this.enterChat(group)
              found = true
          }
          if (found) { break }
      }
  })
  ```
- **关键词**: for循环, break, onClick回调, unclosed delimiter

### 6.4 静态let不支持类类型

- **错误类型**: 编译错误
- **错误信息**:
  ```
  error: expected member name or constructor call after 'HomePage' type name
  public static let PAGE = HomePage
  ```
- **原因分析**: 仓颉不支持静态 let 定义类类型的常量，只能定义原始类型或使用函数返回。
- **解决方案**: 使用函数返回字符串描述替代静态类类型定义：
  ```cangjie
  public class HomeModule {
      public static func getExports(): String {
          "HomeModule: HomePage, HomeTab, HomeViewModel"
      }
  }
  ```
- **关键词**: static let, 类类型, Module定义

### 6.5 组件调用参数完整性

- **错误类型**: 编译错误
- **错误信息**:
  ```
  error: missing arguments for parameter list '(..., Class-ObservedProperty<Class-ArrayList<Class-MessageSearchResult>>>, Class-ObservedProperty<Class-ArrayList<Class-GroupTemplate>>>, ...)'
  expected 20 arguments, found 16
  ```
- **原因分析**: HomeTab 组件新增了 searchMessageResults 和 searchTemplateResults 参数，但 MainTabsContainer.cj 调用时未传递这些参数。
- **解决方案**: 补充完整的参数列表，包括新增的搜索结果参数：
  ```cangjie
  HomeTab(
      // ...原有参数
      searchMessageResults: ArrayList<MessageSearchResult>(),
      searchTemplateResults: ArrayList<GroupTemplate>(),
      updateSearchResults: {=> }
  )
  ```
- **关键词**: 组件参数, missing arguments, HomeTab, MainTabsContainer

---

## 7. EntryView 组件开发经验（2026-04-28）

### 7.1 Button构造方法类型错误

- **错误类型**: 编译错误
- **错误信息**:
  ```
  error: mismatched types
  expected 'Enum-Option<Enum-ButtonRole>', found '() -> Unit'
  Button(ButtonOptions() { this.closeFeatureDialog() })
  ```
- **原因分析**: ButtonOptions构造函数不接受lambda表达式作为参数，它只接受命名参数（shape、stateEffect、buttonStyle等）来配置样式。点击事件应通过.onClick()方法设置。
- **解决方案**: 使用Button的字符串参数构造方法创建按钮，并通过onClick方法设置点击事件：
  ```cangjie
  Button("确定")
      .onClick({ _ => this.closeFeatureDialog() })
      .width(120).height(44)
  ```
- **关键词**: Button, ButtonOptions, 构造函数, lambda参数, mismatched types

---

## 8. MVVM架构重构经验（2026-04-28）

### 8.1 @Observed/@Publish在ViewModel层的使用限制

- **错误类型**: 编译错误
- **错误信息**:
  ```
  error: 'currentTab' is not a member of class 'AppViewModel'
  error: redefinition of declaration 'showFeatureDialog'
  ```
- **原因分析**:
  1. @Observed宏在当前版本存在兼容性问题，生成的ObservedObject子类无法在@Component中正常访问属性
  2. @Observed类中的方法名不能与@Publish属性名重复，宏会为每个属性生成同名getter/setter
- **解决方案**:
  1. ViewModel层使用普通class定义，不使用@Observed/@Publish装饰器
  2. EntryView通过@State绑定AppViewModel实例
  3. 属性访问和方法调用通过普通语法实现
  4. 方法名避免与属性名重复（如showFeatureDialog方法改为openFeatureDialog）
- **正确代码示例**:
  ```cangjie
  // ViewModel层 - 普通class
  public class AppViewModel {
      public var currentTab: Int64 = 0
      public var groups: ArrayList<Group> = ArrayList<Group>()
      
      public init() {}
      
      public func selectTab(index: Int64): Unit {
          this.currentTab = index
      }
  }
  
  // View层 - @State绑定ViewModel
  @Entry
  @Component
  public class EntryView {
      @State var viewModel: AppViewModel = AppViewModel()
      
      public func aboutToAppear(): Unit {
          this.viewModel.loadInitialData()
      }
      
      protected func build() {
          if (this.viewModel.currentTab == 0) {
              // 渲染首页
          }
      }
  }
  ```
- **关键词**: @Observed, @Publish, AppViewModel, ViewModel, MVVM, 属性访问, 方法名冲突

### 8.2 首页推荐群聊消失问题

- **错误类型**: 功能bug
- **错误信息**: 点击首页推荐群聊后再次返回首页，刚才选的群聊从首页消失
- **原因分析**: HomeTab.cj的getUnjoinedTemplates方法错误地过滤掉了已加入的群聊，而AI_Chat1中该方法返回固定的4个推荐模板，不应过滤
- **解决方案**: 修改getUnjoinedTemplates方法，直接返回固定推荐模板列表，不再根据joinedGroupIds过滤
- **正确代码示例**:
  ```cangjie
  // 修复前（错误）
  private func getUnjoinedTemplates(): ArrayList<GroupTemplate> {
      let allTemplates = getRecommendedTemplates()
      let unjoined = ArrayList<GroupTemplate>()
      for (template in allTemplates) {
          var isJoined = false
          for (id in this.joinedGroupIds) { if (id == template.id) { isJoined = true; break } }
          if (!isJoined) { unjoined.add(template) }
      }
      unjoined
  }
  
  // 修复后（正确）
  private func getUnjoinedTemplates(): ArrayList<GroupTemplate> {
      getRecommendedTemplates()  // 直接返回推荐模板，不过滤
  }
  ```
- **关键词**: getUnjoinedTemplates, 首页推荐, 群聊消失, joinedGroupIds过滤

### 8.3 分类详情页UI布局修复

- **错误类型**: UI问题
- **错误信息**: 首页分类点进去后内部UI错乱，布局混乱
- **原因分析**: EntryView.cj中分类详情页实现过于简单，缺少正确的样式和组件化设计
- **解决方案**: 创建CategoryDetailPanel.cj组件，按照AI_Chat1样式实现完整的分类详情页
- **正确代码示例**:
  ```cangjie
  @Component
  public class CategoryDetailPanel {
      @Link var showCategoryDetail: Bool
      @Link var categoryDetailName: String
      @Link var categoryDetailTemplates: ArrayList<GroupTemplate>
      @Link var joinedGroupIds: ArrayList<Int64>
      
      let enterChatByTemplateName: (String) -> Unit
      
      @Builder
      private func buildHeader() {
          Row() {
              Row() {
                  Image(@r(app.media.back)).width(24).height(24)
              }
              .width(40).height(40).borderRadius(20)
              .backgroundColor(0x33FFFFFF)
              .onClick({_ => this.showCategoryDetail = false})
              
              Text(this.categoryDetailName)
                  .fontSize(18).fontWeight(FontWeight.Bold)
                  .layoutWeight(1).textAlign(TextAlign.Center)
              
              Text("").width(40)
          }
          .width(100.percent).padding(left: 24, right: 24, top: 20, bottom: 20)
      }
  }
  ```
- **关键词**: CategoryDetailPanel, 分类详情页, UI布局, @Builder, 组件化
### 8.4 HomeTab 搜索结果不刷新（@Link/@State 断链）

- **错误类型**: 功能bug
- **错误信息**: 首页输入搜索词后结果列表不稳定，父层已更新但 HomeTab 内显示不同步
- **原因分析**: `HomeTab.cj` 将 `searchMessageResults/searchTemplateResults` 定义为 `@State`，而数据源来自父层 `EntryView`。这会导致子组件使用自身状态，和父层搜索结果断链。
- **解决方案**: 将两个字段改为 `@Link`，并在 `EntryView` 中通过 `HomeViewModel` 统一计算搜索结果后整体替换 `ArrayList`，确保刷新触发与父子双向同步一致。
- **正确代码示例**:
  ```cangjie
  // HomeTab.cj
  @Link var searchMessageResults: ArrayList<MessageSearchResult>
  @Link var searchTemplateResults: ArrayList<GroupTemplate>

  // EntryView.cj
  this.homeViewModel.setSearchKeyword(this.searchKeyword, this.groups)
  this.searchMessageResults = ArrayList<MessageSearchResult>(this.homeViewModel.searchMessageResults)
  this.searchTemplateResults = ArrayList<GroupTemplate>(this.homeViewModel.searchTemplateResults)
  ```
- **关键词**: HomeTab, @Link, @State, ArrayList, 搜索结果, 父子状态同步, MVVM

### 8.5 新增持久化模块后依赖找不到（包名与目录不一致）

- **错误类型**: 编译错误
- **错误信息**: `can not find the following dependencies: ohos_app_cangjie_entry.common.persistence`
- **原因分析**: 新增持久化类的 `package` 与实际目录层级不一致，导致 Cangjie 编译期无法解析依赖。
- **解决方案**: 将持久化文件放到与包名一致的目录（`common/persistence`），并统一 `import` 路径。
- **正确代码示例**:
  ```cangjie
  // 文件目录: entry/src/main/cangjie/common/persistence/AppPersistenceService.cj
  package ohos_app_cangjie_entry.common.persistence
  ```
- **关键词**: common.persistence, package, import, can not find dependencies, 目录一致性

### 8.6 @Component 调用链直接追加 transition 导致宏展开参数错位

- **日期**: 2026-04-30
- **错误类型**: 编译错误
- **错误信息**:
  ```
  missing arguments for parameter list ... in call
  unknown named argument prefix 'y:'
  ==> EntryView.cj: SettingsPanel(...).transition(...)
  ```
- **原因分析**: 在 `@Entry/@Component` 的 DSL 宏展开中，直接给 `SettingsPanel(...) / ChatPage(...)` 这类组件调用链追加 `.transition(...)`，会被编译器错误地折叠进组件构造参数，触发“参数数量不匹配”；同时 `TransitionEffect.translate(y: ...)` 命名参数在当前 API 形态下不可用。
- **解决方案**: 回退这类组件实例后的 `transition` 链，统一使用 `animateTo(AnimateParam(..., Curve.Friction))` 控制页面打开/关闭与 Tab 切换动效，保证兼容与可编译。
- **正确代码示例**:
  ```cangjie
  private func switchTabAnimated(tab: Int64): Unit {
      if (this.currentTab == tab) { return }
      getUIContext().animateTo(AnimateParam(duration: 220, curve: Curve.Friction), ({
          => this.currentTab = tab
      }))
  }
  ```
- **关键词**: transition, @Component, 宏展开, 参数错位, animateTo, Curve.Friction

---

## 9. @Component 中禁止声明 static let 常量

- **日期**: 2026-05-11
- **错误类型**: 编译错误
- **错误信息**:
  ```
  error: Declaring static variable in custom component is not allowed.
  ==> PrivacyPolicyDialog.cj:15:13:
  private static let POLICY_LINK: String = "..."
  ```
- **原因分析**: @Component 装饰的 UI 组件类中不允许声明 static let 静态常量。这是 ArkUI 宏系统的限制。
- **解决方案**: 将静态常量移到组件外部的独立 class 中定义，使用 `public class + static let` 形式。
- **正确代码示例**:
  ```cangjie
  // 错误 - 在 @Component 内声明 static let
  @Component
  public class PrivacyPolicyDialog {
      private static let POLICY_LINK: String = "..."  // ❌ 不允许
  }
  
  // 正确 - 在外部 class 中声明
  public class PrivacyPolicyConstants {
      public static let POLICY_LINK: String = "..."  // ✅ 正确
      public init() {}
  }
  
  @Component
  public class PrivacyPolicyDialog {
      // 使用外部常量
      Text(PrivacyPolicyConstants.POLICY_LINK)
  }
  ```
- **关键词**: static let, @Component, 常量声明, 静态变量, custom component

---

## 10. 首次启动隐私政策弹窗实现

- **日期**: 2026-05-11
- **验证状态**: ✅ 构建通过
- **功能描述**: 应用首次启动时弹出隐私政策弹窗，用户必须同意才能继续使用应用。
- **实现要点**:
  1. 在 `AppPersistentState` 新增 `privacyPolicyAccepted: Bool` 字段
  2. 在 `AppPersistenceService` 新增读写逻辑
  3. 在 `EntryView.aboutToAppear()` 中检查状态，未同意则显示弹窗并暂停初始化
  4. 用户同意后调用 `continueInitialization()` 继续初始化流程
  5. 用户不同意时弹窗保持显示（阻止使用但不退出）
  6. 返回键处理：隐私弹窗显示时拦截返回事件
- **文件修改清单**:
  - `common/persistence/AppPersistentState.cj` - 新增字段
  - `common/persistence/AppPersistenceService.cj` - 新增读写
  - `common/components/PrivacyPolicyDialog.cj` - 新建弹窗组件
  - `app/view/EntryView.cj` - 新增状态变量和流程控制
- **关键代码片段**:
  ```cangjie
  // EntryView.cj - aboutToAppear 流程改造
  public func aboutToAppear(): Unit {
      AppBackPressCoordinator.register({=> this.handleSystemBack()})
      let state = AppPersistenceService.load()
      this.privacyPolicyAccepted = state.privacyPolicyAccepted
      if (!this.privacyPolicyAccepted) {
          this.showPrivacyDialog = true
          return  // 暂停初始化
      }
      this.continueInitialization()
  }
  
  private func continueInitialization(): Unit {
      this.groups = this.chatRepository.loadMergedGroups(...)
      this.normalizeGroupsAvatars()
      this.restoreAppState()
      this.reconcileUnreadState()
  }
  
  private func handleSystemBack(): Bool {
      if (this.showPrivacyDialog) {
          return true  // 拦截返回
      }
      // 其他处理...
  }
  ```
- **关键词**: 隐私政策, 首次启动, 弹窗, aboutToAppear, 持久化, 用户同意

---

## 11. 用户不同意隐私政策时退出应用

- **日期**: 2026-05-11
- **验证状态**: ✅ 构建通过
- **功能描述**: 用户点击"不同意"按钮时调用 `UIAbilityContext.terminateSelf()` 退出应用。
- **关键要点**:
  - `terminateSelf()` 返回 `Future<Unit>`，无需 try-catch 处理
  - 需要导入 `ohos.base.*` 和 `ohos_app_cangjie_entry.common.runtime.AppGlobals`
- **正确代码示例**:
  ```cangjie
  // EntryView.cj 导入
  import ohos_app_cangjie_entry.common.runtime.AppGlobals
  import ohos.base.*
  
  // 退出应用实现
  private func onPrivacyDisagreed(): Unit {
      this.showPrivacyDialog = false
      match (AppGlobals.abilityContext) {
          case Some(ctx) => ctx.terminateSelf()
          case None => ()
      }
  }
  ```
- **关键词**: terminateSelf, 退出应用, UIAbilityContext, AppGlobals, Future

---

## 14. AI 群聊架构重构（串行化 + XML Prompt + 深层注入）

- **日期**: 2026-05-21
- **验证状态**: ✅ 构建通过
- **改动概要**:
  1. **Prompt 引擎重写** (`LLMChatService.cj`):
     - `buildSystemPrompt()`/`buildProactiveSystemPrompt()`：改为 XML 结构化格式（`<char_info>` + `<scenario>`），运行时自动为未包裹 `<char_info>` 的 personality 包装标签
     - `buildRequestBody()`：新增 `targetMember` 和 `isProactive` 参数；所有历史消息统一为 `role: "user"` 并加名字前缀（绝对命名法）；在倒数第一条消息前插入 深层注入（Deep Injection）System 指令；动态构造 `stop` 序列防止 AI 越界替其他角色说话
     - 新增 `cleanReplyContent()`：去除模型自加的角色名前缀
     - 废弃 `buildGroupHistory()`/`buildMemberHistory()`/`isMentioned()`
     - `resolveTemperatureByStyle()` 改为接收 `replyStyleLevel` 参数
  2. **串行调度引擎** (`ChatViewModel.cj`):
     - 废弃所有并发相关代码（`requestOnlineReplyParallel`、`replyQueue`、`proactiveQueue`、`processReplyQueue`、`processProactiveQueue` 等）
     - 新增 `processNextReplySequential()` 和 `processNextProactiveSequential()`：每个 AI 成员串行调用，使用最新上下文（上位 AI 刚说的话立刻可见）
     - 每次回复后立即持久化+UI 更新
- **关键设计决策**:
  - `GroupDataCatalog.cj` 不修改，personality 在运行时自动包装 XML
  - Deep Injection 文案控制在 50~300 字
  - 不添加人工 sleep 延迟
- **构建参数**: `--product default`（项目 product 名为 `default`，非 `api23`）
- **关键词**: LLMChatService, ChatViewModel, 串行队列, XML Prompt, Deep Injection, Stop Sequences, 绝对命名, cleanReplyContent

## 12. API 23 HTTP 回调中更新 @State 导致闪退

- **日期**: 2026-05-12
- **错误类型**: 运行时错误
- **错误信息**:
  ```
  message: State updates are not performed on the main thread. 
  stateInfo: stateVarDecl_modelTestStatus_
  stack: at ohos.arkui.state_management.ObservedProperty<...>::set(T0)
         at ohos_app_cangjie_entry.app.view.EntryView::modelTestStatus::set(Int64)
         at ohos_app_cangjie_entry.features.model_config.service.ModelConnectionService::doTestConnectionAsync::lambda.0()
  ```
- **原因分析**: API 23 中 ArkUI 框架强制要求 `@State` 状态更新必须在主线程执行。HTTP 请求回调在非主线程执行，直接更新 `@State` 变量会导致 RuntimeError 闪退。
- **解决方案**: 使用 `launch(task: () -> Unit)` 全局函数将回调调度到主线程执行。注意：`var` 可变变量不能直接在 lambda 中捕获，需先提取到 `let` 不可变变量。
- **正确代码示例**:
  ```cangjie
  // 导入 ArkUI 模块
  import kit.ArkUI.*
  
  // HTTP 回调中使用 launch 调度到主线程
  httpRequest.request(url, option, {err, resp =>
      // 处理响应...
      let result = resultToReturn  // 提取 var 到 let
      httpRequest.destroy()
      launch({ => onResult(result) })  // 主线程调度
  })
  
  // 递归调用也需要包装
  launch({ => doTestConnectionAsync(apiKey, apiUrls, modelName, providerId, onResult, urlIndex + 1, nextErr) })
  ```
- **关键词**: launch, UIThread, 主线程, HTTP回调, @State, 状态更新, RuntimeError, var捕获, lambda, ModelConnectionService, LLMChatService
