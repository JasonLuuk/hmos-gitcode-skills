# arkuix-bridge-codegen 测试提示词

> 运行前提：Node.js ≥ 18（零第三方依赖，全程离线）；输入为 F2 接口适配性扫描产物 `scan-report.json`（③equivalent_bridge / ④degraded_bridge 桶非空时生成五件套）。
> 可选前置：先运行 `arkuix-interface-scan` 产出 scan-report，或使用其 benchmark fixture（`benchmark/fixture-scan-report/`）。

---

## 基础功能测试

### 测试场景 1：④降级桥接五件套生成
**提示词**：
```
我的 F2 扫描报告里 @ohos.telephony.call 判了 degraded_bridge，给它生成 ArkUI-X 桥接骨架，源工程在 /path/to/project，scan-report 在 /path/to/scan-report.json
```

**预期输出**：
- 命令形态：`node scripts/bridge.js <源工程> --scan-report <报告路径> [--out <输出目录>]`，退出码 0
- 五件套落盘：`commons/telephony-call/interface/CallCallInterface.ets`（①契约）、`utils/CallCallLocal.ets`（②OH 侧迁移）、`utils/CallCallArkUIX.ets`（③@arkui-x.bridge 转发）、`.arkui-x/android/.../BridgeCallCall.java` + `BridgeRegistry.java`（④Android）、`.arkui-x/ios/.../BridgeCallCall.h/.m`（⑤iOS）
- ④⑤ 围栏 `ARKUIX-BRIDGE-HANDOFF BEGIN/END` 内含降级说明与标准 TODO（接口/平台/分类三要素）
- `bridge-artifact.json`（BARS-1）与 `bridge-report.md` 产出

### 测试场景 2：③等价桥接映射建议带入围栏
**提示词**：
```
在本仓库的 arkuix-bridge-codegen 目录下执行：node scripts/bridge.js benchmark/fixture-source-project --scan-report benchmark/fixture-scan-report/report.json --out /tmp/bridge-out2
然后读取产物，告诉我 @ohos.batteryInfo 在 Android/iOS 各用什么等价 API，依据是什么
```

**预期输出**：
- 五件套生成同场景 1（fixture 含 batteryInfo③项）
- ④`BridgeBatteryInfoBatterySOC.java` 围栏内带映射建议注释：`// 等价原生 API：android.os.BatteryManager.getIntProperty(BATTERY_PROPERTY_CAPACITY)`
- 映射来源可指证：`rules/native-api-map.json`（`@ohos.batteryInfo` 条目）；未收录项（如 `@ohos.deviceInfo::udid`）进 `bridge-artifact.json` 的 `unmapped_native_apis` 呈报，不猜测

### 测试场景 3：unknown 经 F4 裁决后桥接（链路联动）
**提示词**：
```
先构造裁决后的扫描报告与源工程（模拟 F4 编排器已把 unknown 裁决为③并原地回写 scan-report）：
1) 把 {"schema_version":1,"project_model":"stage","adaptation":{"equivalent_bridge":[{"source":"ohos","module":"@ohos.mockFeature","symbol":"legacy","occurrences":1,"locations":["src/Index.ets:3"],"reason":"F4 编排人工裁决：unknown→③等价桥接","advice":"由 F3 生成桥接","suggested_alternative":""}],"degraded_bridge":[]}} 写入 /tmp/mockproj/scan-adjudicated.json
2) 写 /tmp/mockproj/src/Index.ets 内容为三行：import legacy from '@ohos.mockFeature'; 换行 export function call() { 换行 legacy.doThing(); }
3) 在本仓库 arkuix-bridge-codegen 目录执行：node scripts/bridge.js /tmp/mockproj --scan-report /tmp/mockproj/scan-adjudicated.json --out /tmp/bridge-out3
```

**预期输出**：
- 直连桥接（F4 链内同款机制）：scan-report 中该接口在③桶 → 五件套 `MockFeatureLegacy`（①MockFeatureLegacyInterface/②Local/③ArkUIX/④BridgeMockFeatureLegacy.java/⑤.h/.m）生成
- `bridge-artifact.json` 的 `unmapped_native_apis: ["@ohos.mockFeature::legacy"]`（映射未收录如实呈报）

## 边界条件测试

### 测试场景 4：ndk C-API 接口（无 .ets 迁移源）
**提示词**：
```
先构造扫描报告（C++ 工程形态）：把 {"schema_version":1,"project_model":"stage","adaptation":{"equivalent_bridge":[{"source":"ndk","module":"native_media/avcodec.h","symbol":"OH_AVCodec_Create","occurrences":1,"locations":["src/a.cpp:5"],"reason":"r","advice":"a","suggested_alternative":""},{"source":"ndk","module":"ace/xcomponent/native_interface_xcomponent.h","symbol":"*include*","occurrences":1,"locations":["src/a.cpp:2"],"reason":"r","advice":"a","suggested_alternative":""}],"degraded_bridge":[]}} 写入 /tmp/ndkproj/scan-ndk.json
然后在 /tmp/ndkproj 下建空文件 src/a.cpp，在本仓库 arkuix-bridge-codegen 目录执行：node scripts/bridge.js /tmp/ndkproj --scan-report /tmp/ndkproj/scan-ndk.json --out /tmp/bridge-out4
```

**预期输出**：
- `OH_AVCodec_Create` 四件照常生成（④⑤平台侧承载实现），②Local `local_status: "failed"`，reason 明确 `NDK C-API 无 .ets 迁移源（平台实现于 ④⑤ 侧补齐）`——显式呈报不伪成功
- `*include*` 头文件条目不生成桥接件（stdout 提示跳过数量，报告"头文件依赖跳过清单"段列出）

### 测试场景 5：增量再生成围栏保护
**提示词**：
```
我在 BridgeCallCall.java 围栏内写了 ACTION_DIAL 实现，重新生成桥接件，别覆盖我的代码
```

**预期输出**：
- 重跑 bridge.js：④⑤ 围栏外骨架区幂等更新，围栏内手改区逐字节保留
- ②Local 已存在则整个文件保留开发者版本不覆盖
- bridge-report 中该接口无"覆盖"标记

## 错误处理测试

### 测试场景 6：ScanReport 缺失或损坏
**提示词**：
```
bridge.js 跑的时候 --scan-report 给了个不存在的路径
```

**预期输出**：
- 退出码 2（输入无效），stderr 指明路径不存在
- ScanReport JSON 解析失败 → 退出码 3（格式异常），零产物写入

### 测试场景 7：③④桶均为空的良性完成
**提示词**：
```
我的工程扫描后全是①可直接用，没有需要桥接的接口，跑一下 bridge
```

**预期输出**：
- 退出码 0（良性完成），`bridge-artifact.json` 的 `artifacts: []`、`unmapped_native_apis: []`
- bridge-report 说明无桥接项，不产五件套目录
