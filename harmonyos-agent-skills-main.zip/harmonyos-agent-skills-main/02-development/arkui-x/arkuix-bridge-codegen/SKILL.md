---
name: arkuix-bridge-codegen
description: 消费 F2 接口适配性扫描产物 ScanReport 的 ③equivalent_bridge/④degraded_bridge 分类清单，对每个需桥接接口基于 ArkUI-X Bridge 能力自动生成六件套（①Interface.ets 契约真相源 ②Local.ets HarmonyOS 端 class 实现 ③ArkUIX.ets 桥接 class 实现 ④Android BridgePlugin ⑤iOS BridgePlugin ⑥Impl.ets 平台分发器——一码三平台，对齐 ArkUI-X docs《跨平台Bridge最佳实践》）与 BridgeArtifact(JSON) 桥接报告(Markdown)。开发者在 OH 应用迁移 ArkUI-X 完成接口扫描后、需要生成跨平台桥接骨架时使用；只生成骨架/胶水，平台业务逻辑以 TODO 注解留占位待开发者补齐，增量再生成不覆盖手改区。 Use when 接口适配性扫描产物中存在 equivalent_bridge/degraded_bridge 桶需生成跨平台桥接骨架时。
license: MIT
metadata:
  author: ArkUI-X 团队
  version: "1.1.0"
  created: "2026-10-09"
  updated: "2026-10-13"
  keywords: ["arkui-x", "bridge-codegen", "cross-platform", "migration", "bridgeplugin", "six-piece", "bridge-artifact", "one-code-three-platforms"]
compatibility: Requires Node.js >= 18. Fully offline (no network access); zero third-party dependencies.
---

# ArkUI-X 跨平台桥接代码生成 Skill（F3）

按 扫描（F2）→ 骨架（F1）→ **桥接（本 Skill）** → 编排（F4）工具族分工，本 Skill 消费 F2 ScanReport 的
③equivalent_bridge / ④degraded_bridge 分类，为每个需桥接接口生成标准**六件套**（T8 起对齐 docs 一码三平台范式）：

| # | 件 | 位置（相对输出目录） | 职责 |
|---|-----|---------------------|------|
| ① | Interface.ets | `commons/<module>/interface/{Name}Interface.ets` | 统一接口契约（方法签名），唯一真相源 |
| ② | Local.ets | `commons/<module>/utils/{Name}Local.ets` | **class 实现 ①**：HarmonyOS 端直调 @ohos.*（方法体=源工程原语句迁移） |
| ③ | ArkUIX.ets | `commons/<module>/utils/{Name}ArkUIX.ets` | **class 实现 ①**：@arkui-x.bridge 转发到原生侧（单例+createBridge） |
| ④ | Android Bridge | `.arkui-x/android/.../bridge/Bridge{Name}.java` | BridgePlugin，调映射的 Android API |
| ⑤ | iOS Bridge | `.arkui-x/ios/.../BridgeSrc/Bridge{Name}.h/.m` | BridgePlugin，调映射的 iOS API |
| ⑥ | Impl.ets | `commons/<module>/impl/{Name}Impl.ets` | **平台分发器**：`getInterface()` → Android/iOS 返回③，HarmonyOS 返回②——业务码零平台感知 |

另有**工程级件** `commons/utils/PlatformInfo.ets`（@ohos.deviceInfo.osFullName 平台判断，⑥共用，每工程一份，在场不覆盖）。

**一码三平台语义**：业务调用点统一 `import { XxxImpl }; XxxImpl.getInterface().method(...)`——ArkUI-X 工程（Android/iOS）自动走③桥接，HarmonyOS/OpenHarmony 工程走②Local 直调。同一份 commons 可同时被 ArkUI-X scaffold 与原 OH 工程消费。

## 使用

```bash
node scripts/bridge.js <源工程根目录> --scan-report <ScanReport 路径> [--out <输出目录>]
```

- 退出码：`0` 成功（含③④均空的良性完成、单接口 Local 读取失败的部分成功）；`1` 内部错误；`2` 输入无效；`3` ScanReport 格式异常。
- 全程离线零网络；源工程只读；产物全部落输出目录（默认 `./arkuix-bridge/`）。

## 关键语义

- **①Interface 唯一真相源（F3-Q2）**：②③④⑤ 方法签名均由 ①Interface.ets 派生；签名类型不匹配项列入报告（`rules/type-map.json` 三端类型映射，歧义项标"需人工"）。
- **契约派生多源合并（T4-P0-3）**：方法面=②Local 迁移内容全部 `symbol.method(` 调用 ∪ locations 指向源文件的调用面（同方法名取最大实参面）；参数类型按实参字面量推导（number/boolean/string；回调/对象/数组→ESObject 走签名检查"需人工"通道）；返回统一 `Promise<Bridge.ResultValue>`（③callMethod 的 Bridge 契约形态，非简化遗漏）。
- **②Local 语句提取（T4-P0-1/P0-2 + T8）**：括号深度平衡（嵌套回调内的 `return;` 不截断；字符串/注释/模板串内括号不计深度）；锚定行是 `// [MIG]` N2-B 改写注释/import/空行/纯注释/纯闭合括号行时按 symbol 内容双向重锚定调用行（行号漂移免疫）；同符号连续兄弟语句吸收（sensor.on + sensor.off 全迁）；import 行随语句收割（class 文件顶部）；语句单元按 `.方法名(` 分派到对应类方法体，未命中语句进类尾参考块
- **③/④ 差异策略**：③equivalent_bridge 查 `rules/native-api-map.json`（v1.3.0，模块通配含 @ohos.multimedia.camera→camera2/AVFoundation）映射等价原生 API（未知项列入 `unmapped_native_apis` 待人工确认，不猜测）；④degraded_bridge 对不支持方法留降级占位。
- **TODO 占位标注（R-9）**：④⑤ 业务逻辑区以含 接口名+平台+③④分类 三要素的标准 TODO 注解标注，并置于 `ARKUIX-BRIDGE-HANDOFF BEGIN/END` 围栏内。
- **增量再生成（F3-Q3/R-10）**：重跑时 ①③④⑤ 围栏外骨架区幂等更新；围栏内手改区保留；②Local 文件已存在则保留开发者版本不覆盖（如需重新迁移请先删除该文件）。
- **BridgeArtifact（BARS-1，T4-P2-8）**：每条目含 `symbol`（接口符号名）与 `files` 五件路径（local_status=failed 亦带——供 F4/人工定位）。
- **产物自检兜底（T5）**：六件套落盘后做确定性结构自检（六件齐全 / ①契约方法面 / ②Local 括号平衡·空壳·占位 / ③createBridge·callMethod / ④class extends BridgePlugin / ⑤@interface·@implementation / ⑥Impl·getInterface 分发结构 / 工程级 PlatformInfo），结果入 `bridge-artifact.json` 的 `audit`{checked, **deficient**（硬残缺，必补）, **suggestions**（建议级：contract-thin 单方法兜底契约）} 与报告"产物自检"段（每项含 file/kind/detail/**action**）。**agent 标准动作：`audit.deficient` 非空时，逐项读取 action 指向的生成文件与源工程 locations，补全围栏内实现/契约方法/②Local 语句——补全后重跑本 Skill 幂等不覆盖手改，再走编译验证（ace build apk 产物判定）；suggestions 为可选增强同法处理**。自检不改退出码（残缺=待补信号，非失败；空③④良性完成不产 audit）。

## 产物

- `bridge-artifact.json`：BridgeArtifact（BARS-1 契约，schema_version=1；F4 编排消费）。
- `bridge-report.md`：桥接生成报告（五件套清单/签名不匹配项/unmapped 待确认/Local 失败明细）。

> **临场适配判断（使用方 agent 可选参照）**：`unmapped_native_apis` 非空或④⑤围栏需要适配方案时，
> 可参照 `docs/adaptation-guide.md`（四步判断框架 + 证据校验红线 + 呈报表）给出适配建议，
> 由开发者逐项拍板后落地：默认写围栏注释；开发者明确要求时可代填围栏内实现——
> 按决策生成→编译自检（ace build apk 产物判定）→diff 呈报确认。Skill 本体不因此发生任何行为变化。
> **六件套范式模版（agent 强参照）**：生成/补全/代填/审查任何桥接代码前，先读 `docs/six-piece-paradigm.md`
> （各件金标准形态 + 命名规则 + 跨三端一致性清单 + 不变式）——偏离范式的产物审查不通过（T5 自检 + 模版双闸）。

## 已知限制（如实讲）

- **②Local 方法体的接线深度（T4-P3-10 → T8 → T11 编译保证）**：**类恒可编译**——live 代码仅含 `@ohos.*` 导入与自含 const 内联；引用 `this.X` 成员或未解析标识符的语句以 `// ORIG:` 注释化保留（含原因与接线指引：形参替换实参/赋值改 return/补 import），模块名导入（sample_common 等项目 HAR）同样注释化（需在 oh-package 声明依赖后取消）。**参数/返回值与原语句的接线**仍需人工/agent 补——T5 自检（local-unbalanced/contract-thin/contract-incomplete）继续兜底标记。
- **方法返回类型统一 Promise**：③转发件走 Bridge callMethod（Promise 形态），①契约即此形态——非类型信息缺失；void/同步语义在④⑤平台侧实现时消化。
