// {{interfaceName}}.ets — 五件套①：统一接口契约（签名唯一真相源）
// 由 arkuix-bridge-codegen 生成；②Local/③ArkUIX/④Android/⑤iOS 签名均按本契约映射。
import Bridge from '@arkui-x.bridge';

export interface {{interfaceName}} {
{{methodSignatures}}
}
