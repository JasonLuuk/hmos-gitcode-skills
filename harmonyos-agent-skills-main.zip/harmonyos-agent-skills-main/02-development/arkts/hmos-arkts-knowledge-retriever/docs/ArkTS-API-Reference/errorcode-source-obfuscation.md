# 源码混淆错误码
<!--Kit: ArkTS-->
<!--Subsystem: ArkCompiler-->
<!--Owner: @zju-wyx-->
<!--Designer: @xiao-peiyang; @dengxinyu-->
<!--Tester: @kirl75; @zsw_zhushiwei-->
<!--Adviser: @jinqiuheng-->

> **说明：**
>
> 以下仅介绍本模块特有错误码，通用错误码请参考[通用错误码说明文档](../errorcode-universal.md)。

## 10804001 混淆规则配置文件缺失

**错误信息**

Failed to open obfuscation config file from {path}.

**错误描述**

无法从{path}读取混淆规则配置文件。

**可能原因**

本模块`build-profile.json5`文件中的`arkOptions.obfuscation.ruleOptions`字段中对应的混淆规则配置文件不存在或者路径有误。

**处理步骤**

检查{path}是否存在，路径是否有误。具体可以参考[混淆配置规则文件示例](../../arkts-utils//source-obfuscation-guide.md#开启混淆步骤)。

## 10804002 nameCache.json文件内容格式错误

**错误信息**

Failed to open namecache file from {nameCachePath}, Error message: SyntaxError: Unexpected string in JSON at position 733 At {nameCachePath}.

**错误描述**

无法从指定的名称缓存文件路径{nameCachePath}读取nameCache.json文件。

**可能原因**

该路径下的JSON文件内容格式错误，不符合JSON文件格式要求。

**处理步骤**

找到该{nameCachePath}文件，按照报错信息中提示的行号定位问题所在，并据此进行修改。

## 10804003 keptNames.json文件生成失败

**错误信息**

Failed to open keptNames.json from {defaultUnobfuscationPath}.

**错误描述**

无法从{defaultUnobfuscationPath}读取keptNames.json文件。

**可能原因**

{defaultUnobfuscationPath}路径中没有生成keptNames.json文件。

**处理步骤**

检查{defaultUnobfuscationPath}是否生成keptNames.json文件，若没有，清理缓存后重新编译。

## 10804004 nameCache.json文件不存在

**错误信息**

The applied namecache file {nameCachePath} configured by {configPath} does not exist.

**错误描述**

无法从{nameCachePath}读取-apply-namecache规则配置的json文件。

**可能原因**

在混淆规则配置文件obfuscation-rules.txt中，-apply-namecache配置的json文件不存在。

**处理步骤**

在混淆规则配置文件obfuscation-rules.txt中，检查-apply-namecache配置的json文件路径是否正确。

## 10810001 混淆工具有误，导致文件混淆失败

**错误信息**

ArkTS:INTERNAL ERROR: Failed to obfuscate file 'entry/src/main/ets/entryability/EntryAbility.ets' with arkguard. Error: Obfuscation failed At entry/src/main/ets/entryability/EntryAbility.ets.

**错误描述**

混淆流程执行失败，无法完成文件混淆。

**可能原因**

ArkGuard源码混淆工具内部源码被未经授权的修改。

**处理步骤**

请在DevEco Studio中定位路径`\DevEco-Studio\sdk\default\openharmony\ets\build-tools\ets-loader\node_modules\arkguard`，对比arkguard目录与其同级文件的最后修改日期。如存在差异，请重新下载安装该版本的IDE。