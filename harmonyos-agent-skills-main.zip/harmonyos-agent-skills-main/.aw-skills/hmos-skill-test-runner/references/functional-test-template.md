## 功能性测试用例模板

> 以下为模板格式，复制后填入实际内容。`必填`字段必须填写，`选填`字段可省略。

---

### 测试用例：FUNC-001

**skill**：{skill_name}（必填）  
**类型**：functional（功能验证）

#### 输入

{prompt}

#### 预期输出

**验证标准**：（必填，每条一个独立检查点，逐条判定通过/失败）

- {验证点1}
- {验证点2}
- {验证点3}

**应包含**：{可选，逗号分隔}（选填）  
**不应包含**：{可选，逗号分隔}（选填）  
**格式**：{可选}（选填，markdown/json/yaml/csv）  
**应生成文件**：{可选，逗号分隔}（选填）

---

### 示例一：代码生成型

### 测试用例：FUNC-MIGRATE-001

**skill**：hmos-arkui-statemgt-migration  
**类型**：functional（功能验证）

#### 输入

帮我把以下 V1 代码迁移到 V2：

```
@Component
struct MyComponent {
  @State count: number = 0
  @Prop title: string = ''
  @Link externalValue: number

  build() {
    Column() {
      Text(this.title)
      Text(`${this.count}`)
      Button('add').onClick(() => { this.count++ })
    }
  }
}
```

#### 预期输出

**验证标准**：

- 迁移后代码应功能等价，count 可内部修改，title 只读，双向同步通过 @Param+@Event 手动实现
- 装饰器用法正确，@Local 不允许外部初始化
- 类型注解完整，无 any/unknown
- 生成的代码应可编译，无语法错误

**应包含**：@ComponentV2, @Local, @Param, @Event  
**不应包含**：@State, @ObjectLink

---

### 示例二：审查型

### 测试用例：FUNC-AUDIT-001

**skill**：app-metadata-audit-skill  
**类型**：functional（功能验证）

#### 输入

按照 app-metadata-audit-skill 规范，审查以下华为应用元数据：

- 应用名称：免费WiFi万能钥匙
- 一句话简介：免费WiFi万能钥匙连接神器
- 应用介绍：本应用提供免费WiFi连接功能，Android和iOS用户均可使用。
- 隐私政策网址：https://example.com/not-found

#### 预期输出

**验证标准**：

- 应检测到名称含营销词"免费"
- 应检测到介绍含竞品词 Android 和 iOS
- 应检测到一句话简介与名称重复
- 应检测到隐私政策网址可能无法访问
- 每个问题应标注风险级别（BLOCKER/WARNING/INFO）
- 审计报告应为表格格式，含字段/状态/问题说明/建议修改方案四列

**应包含**：Android, iOS, 免费  
**格式**：markdown

---

### 示例三：工具型

### 测试用例：FUNC-INSTR-001

**skill**：hmos-instrument-test  
**类型**：functional（功能验证）

#### 输入

我的工程是 /home/project/MyApp，帮我运行 entry/ohosTest/ets/test/Ability.test.ets 中的 ActsAbilityTest 测试套件，不需要覆盖率

#### 预期输出

**验证标准**：

- 应从测试文件路径推断出 module 为 entry
- 应从套件名推断出 scope 为 ActsAbilityTest
- 用户明确不需要覆盖率，应传 --no-coverage
- 不应传入用户未提及的参数（如 --asan、--timeout）

**应包含**：--module, --scope, ActsAbilityTest, --no-coverage  
**不应包含**：--asan

---

### 示例四：知识库型

### 测试用例：FUNC-RETRIEVE-001

**skill**：hmos-arkui-knowledge-retriever  
**类型**：functional（功能验证）

#### 输入

@Local 装饰器怎么用？和 @State 有什么区别？

#### 预期输出

**验证标准**：

- 应解释 @Local 的基本用法和适用场景
- 应说明 @Local 禁止外部初始化，需用 @Param @Once 替代
- 应说明 @Local 只观测变量本身，深度观测需配合 @ObservedV2 + @Trace
- 应对比 @State 可观测第一层属性且支持外部初始化
- 应标注知识库来源路径

**应包含**：@Local, @State

---

### 示例五：流程引导型

### 测试用例：FUNC-ATOMIC-001

**skill**：hmos-atomicservice-assistant  
**类型**：functional（功能验证）

#### 输入

我要新建一个鸿蒙元服务，主要功能是快速记笔记。需要满足哪些合规要求？

#### 预期输出

**验证标准**：

- 应给出完整的合规检查清单
- 应覆盖以下维度：bundleType 设置、@atomicservice API 标注、ArkWeb 禁用、隐私托管、静默登录、包大小限制、ICP 备案
- 每项应标注是 Critical 还是 Warning 级别
- 应给出可直接操作的下一步指导

**应包含**：bundleType, 2MB, 隐私托管, ICP
